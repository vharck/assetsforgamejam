using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;

public class GameManager : MonoBehaviour
{
    #region Singleton

    private static GameManager _instance;
    public static GameManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<GameManager>();
                if (_instance == null)
                {
                    GameObject singleton = new(typeof(GameManager).Name);
                    _instance = singleton.AddComponent<GameManager>();
                    DontDestroyOnLoad(singleton);
                }
            }
                
            return _instance;
        }
    }

    private void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
            Destroy(this);
    }

    #endregion

    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private List<InputActionAsset> playerInput;

    private List<PlayerController> players;

    [SerializeField] private List<Transform> playerSpawnPoint;

    [SerializeField] private List<SkillCard> weaponsCards;
    [SerializeField] private List<SkillCard> fishCards;
    [SerializeField] private List<SkillCard> powerUpCards;
    [SerializeField] private List<SkillCard> effectCards;

    #region Spawn Players

    public void SpawnPlayers(int playerCount)
    {
        for (int i = 0; i < playerCount; i++)
        {
            var player = Instantiate(playerPrefab);
            var inputs = player.GetComponent<PlayerInput>();
            inputs.actions = playerInput[i];

            var controller = player.GetComponent<PlayerController>();
            controller.enabled = true;
            players.Add(controller);
            players[i].transform.position = playerSpawnPoint[i].transform.position;
            players[i].SetupPlayer(i, fishCards[0], weaponsCards[0]);
            players[i].GetComponent<PlayerMovement>().enabled = true;
            players[i].GetComponent<WeaponController>().enabled = true;

        }
    }

    #endregion

    #region Rounds

    [SerializeField] private List<RoundType> roundSequence;
    private int[] playersRounds = {0,0};

    private int roundPlayer;

    public void CardsSelection(int player)
    {
        List<SkillCard> rest = new();

        roundPlayer = player;

        switch (roundSequence[playersRounds[player]])
        {
            case RoundType.Weapon:
                rest = weaponsCards.Except(players[player].skillCards).ToList();
                break;
            case RoundType.Fish:
                rest = fishCards.Except(players[player].skillCards).ToList();
                break;
            case RoundType.PowerUp:
                rest = powerUpCards.Except(players[player].skillCards).ToList();
                break;
            default:
                List<SkillCard> weapons = weaponsCards.Except(players[player].skillCards).ToList();
                List<SkillCard> fish = fishCards.Except(players[player].skillCards).ToList();
                List<SkillCard> powerUps = powerUpCards.Except(players[player].skillCards).ToList();
                List<SkillCard> effects = effectCards.Except(players[player].skillCards).ToList();
                rest.AddRange(weapons);
                rest.AddRange(fish);
                rest.AddRange(powerUps);
                rest.AddRange(effects);
                break;
        }

        SkillCard[] cards = new SkillCard[UIManager.Instance.numberOfCards];

        for (int i = 0; i < UIManager.Instance.numberOfCards; i++)
        {
            int random = Random.Range(0, rest.Count);
            cards[i] = rest[random];
            rest.RemoveAt(random);
        }

        UIManager.Instance.SetupCards(cards);
    }

    public void CardSelected(SkillCard card)
    {
        players[roundPlayer].skillCards.Add(card);
        playersRounds[roundPlayer]++;
    }

    #endregion
}

public enum RoundType
{
    Weapon,
    Fish,
    PowerUp,
    Random
}