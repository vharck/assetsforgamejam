using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleSystem : MonoBehaviour
{
    [SerializeField] private PlayerController controller;

    private CircleCollider2D col;

    private void Awake()
    {
        col = GetComponent<CircleCollider2D>();
    }

    public void Setup(float range)
    {
        col.radius = range;
    }

    public void ActivateBubble()
    {
        
    }

    public void DeactivateBubble()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (controller.State == PlayerState.Pop) return;
        if (!collision.TryGetComponent<WeaponCollision>(out var wp)) return;

        if (wp.playerID != controller.PlayerID)
        {
            controller.OnPop();
            collision.GetComponentInParent<PlayerController>().HitBubbleEvent();
        }
    }
}
