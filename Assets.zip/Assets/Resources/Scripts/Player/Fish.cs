using UnityEngine;

[CreateAssetMenu(fileName = "New Fish", menuName = "Scriptables/Fish")]
public class Fish : ScriptableObject
{
    public FishType fishType;
    public float bubbleMoveAcc;
    public float bubbleMaxSpeed;
    public float bubbleSizeMultiplier;

    public float popJumpMulti;
    public float bubbleRegenCooldown;
    public float fishMoveSpeed;
    public float jumpDistance;
    public float jumpDuration;
    public float jumpCooldown;
}

public enum FishType
{
    Default,
    DefaultPlus,
    Goldfish,
    Shrimp,
    Crab,
    Octopus,
    Pufferfish,
    Lionfish,
    Swordfish
}