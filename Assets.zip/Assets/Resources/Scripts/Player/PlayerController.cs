using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;

[RequireComponent (typeof(PlayerMovement))]
[RequireComponent (typeof(WeaponController))]
[RequireComponent (typeof(CircleCollider2D))]
public class PlayerController : MonoBehaviour
{
    private Collider2D bubbleCollider;
    private Collider2D fishCollider;
    public SpriteRenderer fishSpriteRender;
    public SpriteRenderer weaponSpriteRender;
    public SpriteRenderer bubbleSpriteRender;

    public PlayerMovement Movement { get; private set; }
    public WeaponController WpnController { get; private set; }

    public Fish Fish{ get; private set; }
    public Weapon Weapon { get; private set; }

    public List<SkillCard> skillCards = new ();

    public int PlayerID { get; private set; }

    public PlayerState State { get; private set; }

    private void Awake()
    {
        Movement = GetComponent<PlayerMovement>();
        WpnController = GetComponent<WeaponController>();

        State = PlayerState.Freezed;
    }

    public void SetupPlayer(int playerID, SkillCard fish, SkillCard weapon)
    {
        PlayerID = playerID;

        skillCards.Add(fish);
        skillCards.Add(weapon);

        Fish = fish.fish;
        Weapon = weapon.weapon;
    }

    private void ApplyBonusFish(SkillCard[] cards)
    {
        foreach (var card in cards)
        {
            Fish.fishMoveSpeed += card.powerUp.fishSpeedFlat;
            Fish.fishMoveSpeed *= card.powerUp.fishSpeedMultiplier;
            Fish.bubbleMaxSpeed += card.powerUp.bubbleSpeedFlat;
            Fish.bubbleMoveAcc += card.powerUp.bubbleSpeedFlat;
            Fish.bubbleMaxSpeed *= card.powerUp.bubbleSpeedMultiplier;
            Fish.bubbleMoveAcc *= card.powerUp.bubbleSpeedMultiplier;
        }
    }

    private void ApplyBonusWeapon(SkillCard[] cards)
    {
        foreach (var card in cards)
        {
            weaponSpriteRender.transform.localScale *= card.powerUp.weaponSizeMultiplier;
            Weapon.rotationMaxSpeed += card.powerUp.weaponSpeedFlat;
            Weapon.rotationAcc += card.powerUp.weaponSpeedFlat;
            Weapon.rotationMaxSpeed *= card.powerUp.weaponSpeedMultiplier;
            Weapon.rotationAcc *= card.powerUp.weaponSpeedMultiplier;
        }
    }

    public void NewCard(SkillCard card)
    {
        skillCards.Add(card);
        switch (card.cardType)
        {
            case SkillCardType.Fish:
                if(Fish != null)
                {
                    switch (Fish.fishType)
                    {
                        case FishType.Swordfish:
                            UnSwordfishSetup();
                            break;
                        case FishType.Lionfish:
                            UnLionfishSetup();
                            break;
                        case FishType.Octopus:
                            UnOctopusSetup();
                            break;
                    }
                }
                Fish = card.fish; 
                ApplyBonusFish(new SkillCard[] { card });
                switch (Fish.fishType)
                {
                    case FishType.Swordfish:
                        SwordfishSetup();
                        break;
                    case FishType.Lionfish:
                        LionfishSetup();
                        break;
                    case FishType.Octopus:
                        OctopusSetup();
                        break;
                }
                break;
            case SkillCardType.Weapon:
                Weapon = card.weapon;
                ApplyBonusWeapon(new SkillCard[] { card });



                break;
            case SkillCardType.PowerUp:
                ApplyBonusFish(new SkillCard[] { card });
                ApplyBonusWeapon(new SkillCard[] { card });

                bubbleSpriteRender.transform.localScale *= card.powerUp.bubbleSizeMultiplier;
                break;
            case SkillCardType.Effect:
                gameObject.AddComponent(System.Type.GetType(card.powerUp.effectComponentName));
                break;
        }
    }

    #region Pop

    public float PopTimer { get; private set; }

    public void OnPop()
    {
        if (State == PlayerState.Pop)
        {
            OnHit();
            return;
        }

        State = PlayerState.Pop;
        PopTimer = Fish.bubbleRegenCooldown + Time.time;
        PopEvent();
    }

    public void OnUnpop()
    {
        State = PlayerState.Normal;
        UnpopEvent();
    }

    #endregion

    #region Hit

    private void OnHit()
    {
        State = PlayerState.Dead;
        DeathEvent();
    }

    #endregion

    #region Death

    private void OnDeath()
    {

    }

    #endregion

    private void LateUpdate()
    {
        if (State == PlayerState.Pop && PopTimer < Time.time)
        {
            OnUnpop();
        }
        if (State == PlayerState.Dead)
        {
            OnDeath();
        }
    }

    #region Events

    public delegate void OnPopHandler();
    public event OnPopHandler OnPopEvent;
    public void AddOnPop(OnPopHandler handler) => OnPopEvent += handler;
    public void PopEvent() => OnPopEvent?.Invoke();

    public delegate void OnUnpopHandler();
    public event OnUnpopHandler OnUnpopEvent;
    public void AddOnUnpop(OnUnpopHandler handler) => OnUnpopEvent += handler;
    public void UnpopEvent() => OnUnpopEvent?.Invoke();

    public delegate void OnHitBubbleHandler();
    public event OnHitBubbleHandler OnHitBubbleEvent;
    public void AddOnHitBubble(OnHitBubbleHandler handler) => OnHitBubbleEvent += handler;
    public void HitBubbleEvent() => OnHitBubbleEvent?.Invoke();

    public delegate void OnHitWeaponHandler();
    public event OnHitWeaponHandler OnHitWeaponEvent;
    public void AddOnHitWeapon(OnHitWeaponHandler handler) => OnHitWeaponEvent += handler;
    public void HitWeaponEvent() => OnHitWeaponEvent?.Invoke();

    public delegate void OnDeathHandler();
    public event OnDeathHandler OnDeathEvent;
    public void AddOnDeath(OnDeathHandler handler) => OnDeathEvent += handler;
    public void DeathEvent() => OnDeathEvent?.Invoke();

    public delegate void OnJumpHandler();
    public event OnJumpHandler OnJumpEvent;
    public void AddOnJump(OnJumpHandler handler) => OnJumpEvent += handler;
    public void JumpEvent() => OnJumpEvent?.Invoke();

    public delegate void OnLandingHandler();
    public event OnLandingHandler OnLandingEvent;
    public void AddOnLanding(OnLandingHandler handler) => OnLandingEvent += handler;
    public void LandingEvent() => OnLandingEvent?.Invoke();


    #endregion

    #region Powers

    public bool hasQuickSlash {get; private set; }

    #region Swordfish

    [Header("Swordfish")]
    [SerializeField] private GameObject fishNose;

    private GameObject fishNoseInstance; 

    private void SwordfishSetup()
    {
        OnPopEvent += SwordfishActivation;
        OnUnpopEvent += SwordfishDeactivation;

        fishNoseInstance = Instantiate(fishNose, transform);
    }

    private void UnSwordfishSetup()
    {
        OnPopEvent -= SwordfishActivation;
        OnUnpopEvent -= SwordfishDeactivation;

        Destroy(fishNoseInstance);
    }

    private void SwordfishActivation() => fishNoseInstance.SetActive(true);
    private void SwordfishDeactivation() => fishNoseInstance.SetActive(false);

    #endregion

    #region Lionfish

    [Header("Lionfish")]
    [SerializeField] private GameObject fishTrail;
    private bool isSlowed = false;

    private void LionfishSetup() => OnLandingEvent += LionfishActivation;

    private void UnLionfishSetup() => OnLandingEvent -= LionfishActivation;

    private void LionfishActivation()
    {
        Instantiate(fishTrail, transform.position, Quaternion.identity);
    }

    public IEnumerator Slow()
    {
        if (isSlowed) yield break;
        isSlowed = true;
        Fish.bubbleMaxSpeed /= 2;
        var color = bubbleSpriteRender.color;
        bubbleSpriteRender.color = Color.green;
        yield return new WaitForSeconds(3);
        bubbleSpriteRender.color = color;
        Fish.bubbleMaxSpeed *= 2;
        isSlowed = false;
    }

    #endregion

    #region Octopus

    [Header("Octopus")]
    [SerializeField] private GameObject octopusTrail;

    private void OctopusSetup() 
    { 
        OnPopEvent += OctopusActivation;
        OnUnpopEvent += UnOctopusSetup;
    }

    private void UnOctopusSetup() 
    {
        OnPopEvent -= OctopusActivation;
        var color = fishSpriteRender.color;
        color.a = 1;
        fishSpriteRender.color = color;
    }

    private void OctopusActivation()
    {
        StartCoroutine(OctopusEffect());
    }

    private IEnumerator OctopusEffect()
    {
        for (int i = 0; i < 15; i++)
        {
            var color = fishSpriteRender.color;
            color.a -= 0.05f;
            fishSpriteRender.color = color;
            yield return new WaitForSeconds(0.05f);
        }
        for (int i = 0; i < Fish.bubbleRegenCooldown - 1; i++)
        {
            Instantiate(octopusTrail, transform.position, Quaternion.identity);
            yield return new WaitForSeconds(1f);
        }
    }

    #endregion

    #endregion
}

public enum PlayerState
{
    Freezed,
    Normal,
    Pop,
    Dead
}