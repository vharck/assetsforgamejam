using System.Collections;
using UnityEngine;

using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement : MonoBehaviour
{
    #region Movement

    private Vector2 input = Vector2.zero;

    private bool moveEnable = true;
    private Rigidbody2D rb;

    private PlayerController controller;

    [SerializeField] private Transform spriteTransform;

    public void EnableMove(bool value) => moveEnable = value;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        controller = GetComponent<PlayerController>();

        rb.gravityScale = 0;
        rb.freezeRotation = true;
    }

    public void OnMovement(InputAction.CallbackContext context) => input = context.ReadValue<Vector2>();

    private void Movement()
    {
        var x = input.x == 0
            ? Mathf.MoveTowards(rb.velocity.x, 0, controller.Fish.bubbleMoveAcc * Time.deltaTime)
            : Mathf.MoveTowards(rb.velocity.x, input.x * controller.Fish.bubbleMaxSpeed, Mathf.Abs(input.x) * controller.Fish.bubbleMoveAcc * Time.deltaTime);
        var y = input.y == 0
            ? Mathf.MoveTowards(rb.velocity.y, 0, controller.Fish.bubbleMoveAcc * Time.deltaTime)
            : Mathf.MoveTowards(rb.velocity.y, input.y * controller.Fish.bubbleMaxSpeed, Mathf.Abs(input.y) * controller.Fish.bubbleMoveAcc * Time.deltaTime);
        rb.velocity = new Vector2(x, y);
    }

    #endregion

    #region Pop Movement

    private Vector2 jumpInput;
    private float jumpCooldown = 0;
    private float jumpDuration = 0;

    private bool firstJump = true;

    private bool IsJumping => jumpDuration > Time.time;
    private bool CanJump => jumpCooldown < Time.time && !NonJumper;
    private bool NonJumper => controller.Fish.fishType == FishType.Octopus || controller.Fish.fishType == FishType.Crab;

    private float arkTimer = 0;
    private float frequency;
    private float amplitude;

    private IEnumerator JumpTimer()
    {
        yield return new WaitForSeconds(controller.Fish.jumpDuration);
        controller.LandingEvent();
    }

    private void PopMovement()
    {
        if (firstJump)
        {
            jumpInput = input * controller.Fish.popJumpMulti;
            firstJump = false;

            frequency = 16.66f * controller.Fish.jumpDuration * controller.Fish.jumpDistance * controller.Fish.popJumpMulti / (2 * Mathf.PI);
            amplitude = controller.Fish.jumpDistance * controller.Fish.popJumpMulti / 4;
            arkTimer = 0;
            jumpDuration = Time.time + controller.Fish.jumpDuration;
            jumpCooldown = Time.time + controller.Fish.jumpCooldown;

            controller.JumpEvent();
            StartCoroutine(JumpTimer());
        }
        else if (IsJumping)
        {
            rb.velocity = Time.deltaTime * (60 * controller.Fish.jumpDistance / controller.Fish.jumpDuration) * jumpInput;
            arkTimer += Time.deltaTime;
            spriteTransform.localPosition = new Vector2(0, amplitude * Mathf.Sin(frequency * arkTimer));
        }
        else if (CanJump)
        {
            jumpInput = input;
            frequency = 16.66f * controller.Fish.jumpDuration * controller.Fish.jumpDistance / (2 * Mathf.PI);
            amplitude = controller.Fish.jumpDistance / 4;
            arkTimer = 0;
            jumpDuration = Time.time + controller.Fish.jumpDuration;
            jumpCooldown = Time.time + controller.Fish.jumpCooldown;

            controller.JumpEvent();
            StartCoroutine(JumpTimer());
        }
        else if (moveEnable)
        {
            if (controller.Fish.fishType == FishType.Crab) input.y = 0;
            rb.velocity = Time.deltaTime * controller.Fish.fishMoveSpeed * input;
        }

    }

    #endregion

    public Vector2 forcedMove = Vector2.zero;

    private void FixedUpdate()
    {
        if (controller.State == PlayerState.Pop) PopMovement();
        else
        {
            if (moveEnable) Movement();
            rb.velocity += forcedMove;
            spriteTransform.transform.localPosition = Vector3.zero;
            firstJump = true;
        }
    }
}