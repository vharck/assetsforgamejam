using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect : MonoBehaviour
{
    public List<ActivationType> activationTypes = new();

    public virtual void OnPop() { }

    public virtual void OnUnpop() { }

    public virtual void OnHitBubble() { }

    public virtual void OnHitWeapon() { }

    public virtual void OnWeaponHit() { }

    public virtual void OnDeath() { }

    public virtual void OnJump() { }

    public virtual void OnLanding() { }

    private void Awake()
    {
        var effects = GetComponents<Effect>();
        var controller = GetComponent<PlayerController>();

        foreach (var effect in effects)
        {
            effect.activationTypes.ForEach(type =>
            {
                switch (type)
                {
                    case ActivationType.OnPop:
                        PlayerController.OnPopHandler onPopHandler;
                        onPopHandler = effect.OnPop;
                        controller.AddOnPop(onPopHandler);
                        break;
                    case ActivationType.OnUnpop:
                        PlayerController.OnUnpopHandler onUnpopHandler;
                        onUnpopHandler = effect.OnUnpop;
                        controller.AddOnUnpop(onUnpopHandler);
                        break;
                    case ActivationType.OnHitBubble:
                        PlayerController.OnHitBubbleHandler onHitBubbleHandler;
                        onHitBubbleHandler = effect.OnHitBubble;
                        controller.AddOnHitBubble(onHitBubbleHandler);
                        break;
                    case ActivationType.OnHitWeapon:
                        PlayerController.OnHitWeaponHandler onHitWeaponHandler;
                        onHitWeaponHandler = effect.OnHitWeapon;
                        controller.AddOnHitWeapon(onHitWeaponHandler);
                        break;
                    case ActivationType.OnDeath:
                        PlayerController.OnDeathHandler onDeathHandler;
                        onDeathHandler = effect.OnDeath;
                        controller.AddOnDeath(onDeathHandler);
                        break;
                    case ActivationType.OnJump:
                        PlayerController.OnJumpHandler onJumpHandler;
                        onJumpHandler = effect.OnJump;
                        controller.AddOnJump(onJumpHandler);
                        break;
                    case ActivationType.OnLanding:
                        PlayerController.OnLandingHandler onLandingHandler;
                        onLandingHandler = effect.OnLanding;
                        controller.AddOnLanding(onLandingHandler);
                        break;
                }
            });
        }
    }
}

public enum ActivationType
{
    OnPop, //
    OnUnpop, //
    OnHitBubble, //
    OnHitWeapon, //
    OnDeath, //
    OnJump, //
    OnLanding //
}
