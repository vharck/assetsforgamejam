using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishTrail : MonoBehaviour
{
    public int playerID;

    private void Awake()
    {
        Destroy(gameObject, 1.5f);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.TryGetComponent<PlayerController>(out var controller))
        {
            if (controller.PlayerID == playerID) return;

            StartCoroutine(controller.Slow());
        }
    }
}
