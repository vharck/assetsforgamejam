using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OctopusTrail : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        Destroy(gameObject, 1);

        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        var color = spriteRenderer.color;
        color.a -= Time.deltaTime;
        spriteRenderer.color = color;
    }
}
