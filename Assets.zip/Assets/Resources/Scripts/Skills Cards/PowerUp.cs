using UnityEngine;

public class PowerUp : ScriptableObject
{
    public PowerUpType powerUpType;
    [Header("Fish Stats")]
    public float fishSpeedFlat;
    public float fishSpeedMultiplier;

    [Header("Bubble Stats")]
    public float bubbleSpeedFlat;
    public float bubbleSpeedMultiplier;
    public float bubbleSizeMultiplier;

    [Header("Weapon Stats")]
    public float weaponSizeMultiplier;
    public float weaponSpeedFlat;
    public float weaponSpeedMultiplier;

    [Header("Other Effects")]
    public string effectComponentName;

}

public enum PowerUpType
{
    FishStats,
    BubbleStats,
    WeaponStats,
    Effect
}