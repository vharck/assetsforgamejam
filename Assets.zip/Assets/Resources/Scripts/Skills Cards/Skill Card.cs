using UnityEngine;

[CreateAssetMenu(fileName = "New Skill Card", menuName = "Scriptables/Skill Card")]
public class SkillCard : ScriptableObject
{
    public string cardName;
    public string flavorText;
    public string description;
    public Sprite cardImage;
    public SkillCardType cardType;

    public Fish fish;
    public Weapon weapon;
    public PowerUp powerUp;
}

public enum SkillCardType
{
    Weapon,
    Fish,
    PowerUp,
    Effect
}
