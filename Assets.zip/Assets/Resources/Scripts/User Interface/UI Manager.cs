using TMPro;
using UnityEngine;
using UnityEngine.UIElements;

public class UIManager : MonoBehaviour
{
    #region Singleton

    private static UIManager _instance;
    public static UIManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<UIManager>();
                if (_instance == null)
                {
                    GameObject singleton = new(typeof(UIManager).Name);
                    _instance = singleton.AddComponent<UIManager>();
                    DontDestroyOnLoad(singleton);
                }
            }

            return _instance;
        }
    }

    private void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
            Destroy(this);
    }

    #endregion

    #region Canvas Toggle

    [SerializeField] private Canvas Intro;
    [SerializeField] private Canvas MainMenuPanel;
    [SerializeField] private Canvas CharacterSelectionPanel;
    [SerializeField] private Canvas GamePanel;
    [SerializeField] private Canvas PausePanel;
    [SerializeField] private Canvas CardSelection;
    [SerializeField] private Canvas GameOverPanel;

    public void ShowIntro()
    {
        Intro.gameObject.SetActive(true);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowMainMenu()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(true);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowCharacterSelection()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(true);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowGamePanel()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(true);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowPausePanel()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(true);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowCardSelection()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(true);
        GameOverPanel.gameObject.SetActive(false);
    }

    public void ShowGameOverPanel()
    {
        Intro.gameObject.SetActive(false);
        MainMenuPanel.gameObject.SetActive(false);
        CharacterSelectionPanel.gameObject.SetActive(false);
        GamePanel.gameObject.SetActive(false);
        PausePanel.gameObject.SetActive(false);
        CardSelection.gameObject.SetActive(false);
        GameOverPanel.gameObject.SetActive(true);
    }

    #endregion

    #region
    [Header("Cards Components")]
    public int numberOfCards;
    [SerializeField] private Image[] cardBackground;
    [SerializeField] private Image[] cardImage;
    [SerializeField] private TextMeshPro[] cardName;
    [SerializeField] private TextMeshPro[] cardFlavor;
    [SerializeField] private TextMeshPro[] cardDescription;
    private SkillCard[] cardHolder;
    [Header("Backgrounds")]
    [SerializeField] private Sprite weaponBackground;
    [SerializeField] private Sprite fishBackground;
    [SerializeField] private Sprite powerUpBackground;
    [SerializeField] private Sprite effectBackground;

    public void SetupCards(SkillCard[] cards)
    {
        for (int i = 0; i < cards.Length; i++)
        {
            cardBackground[i].sprite = cards[i].cardType switch
            {
                SkillCardType.Weapon => weaponBackground,
                SkillCardType.Fish => fishBackground,
                SkillCardType.PowerUp => powerUpBackground,
                SkillCardType.Effect => effectBackground,
                _ => throw new System.NotImplementedException()
            };
            cardImage[i].sprite = cards[i].cardImage;
            cardName[i].text = cards[i].cardName;
            cardFlavor[i].text = cards[i].flavorText;
            cardDescription[i].text = cards[i].description;
            cardHolder[i] = cards[i];
        }

        ShowCardSelection();
    }

    public void SelectCard(int card)
    { 
        GameManager.Instance.CardSelected(cardHolder[card]); 
        ShowGamePanel();
    }

    #endregion

    public void QuitGame()
    {
        Application.Quit();
    }
}
