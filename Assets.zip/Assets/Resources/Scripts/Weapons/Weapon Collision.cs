using UnityEngine;

public class WeaponCollision : MonoBehaviour
{
    private WeaponController weaponController;
    private PlayerController playerController;
    public int playerID => playerController.PlayerID;

    private void Awake()
    {
        playerController = GetComponentInParent<PlayerController>();
        weaponController = playerController.WpnController;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent<WeaponCollision>(out var col))
        {
            Debug.Log(col.playerID + " " + playerID);
            if (col.playerID != playerID)
            {
                var weapon = col.GetComponentInParent<WeaponController>();
                float sign = weapon.CurrentSpeed != 0 ? (-Mathf.Sign(weapon.CurrentSpeed)) : (Mathf.Sign(weapon.CurrentSpeed));
                float multiplier = (Mathf.Abs(weaponController.CurrentSpeed) / playerController.Weapon.rotationMaxSpeed);

                weapon.RecivedKnockback(sign * multiplier * playerController.Weapon.knockbackStrength);

                Debug.Log("Player " + playerID + " hit Player " + col.playerID);
            }
        }
    }
}
