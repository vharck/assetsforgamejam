using UnityEngine;

[CreateAssetMenu(fileName = "New Weapon", menuName = "Scriptables/Weapon")]
public class Weapon : ScriptableObject
{
    [Header("General Value")]
    public WeaponType weaponType;
    public float rotationAcc = 10;
    public float rotationMaxSpeed = 150;
    public float knockbackStrength = 100;
    public float knockbackResistance = 0.5f;
    public float knockbackDuration = 0.2f;
    [Header("Piercing")]
    public float maxPiercingDistance = 1;
    public float piercingSpeed = 10;
    public float piercingReturningSpeed = 10;
    public float piercingCooldown = 1;
}

public enum WeaponType
{
    Default,
    Rapier,
    Trident,
    Warhammer,
    DragonSlayer,
    Zweihander,
    Scimitar,
    Katana,
    DoubleBlade,
    Halberd,
    LittleHammer
}