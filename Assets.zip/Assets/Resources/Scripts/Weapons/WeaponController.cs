using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class WeaponController : MonoBehaviour
{
    private PlayerController controller;

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
    }

    #region Weapon Commands

    [SerializeField] private Transform rotationCenter;
    [SerializeField] private Transform weaponHolder;

    private bool isLeftPressed = false;
    private bool isRightPressed = false;

    public float CurrentSpeed { get; private set; }

    private void Start()
    {
        holderOriginalPosition = weaponHolder.transform.localPosition;
        CurrentSpeed = 0;

        PlayerController.OnHitBubbleHandler onHitBubbleHandler;
        onHitBubbleHandler = HitBubble;
        controller.AddOnHitBubble(onHitBubbleHandler);
    }

    public void OnWeaponLeft(InputAction.CallbackContext context)
    {
        switch (context.phase)
        {
            case InputActionPhase.Started:
                isLeftPressed = true;
                break;
            case InputActionPhase.Canceled:
                isLeftPressed = false;
                break;
        }
    }

    public void OnWeaponRight(InputAction.CallbackContext context)
    {
        switch (context.phase)
        {
            case InputActionPhase.Started:
                isRightPressed = true;
                break;
            case InputActionPhase.Canceled:
                isRightPressed = false;
                break;
        }
    }

    private void UpdateWeaponRotation()
    {
        if (isLeftPressed)
        {
            Rotate(controller.Weapon.rotationAcc);
        }
        else if (isRightPressed)
        {
            Rotate(-controller.Weapon.rotationAcc);
        }
        else
        {
            Rotate(0);
        }
    }

    #endregion

    #region Weapon Knockback

    private bool InKnockback => knockbackTimer > Time.time;
    private float knockbackStrength = 0;
    private float knockbackTimer = 0;

    public void RecivedKnockback(float strength)
    {
        knockbackStrength = strength * controller.Weapon.knockbackResistance;
        knockbackTimer = controller.Weapon.knockbackDuration + Time.time;

        controller.HitWeaponEvent();
    }

    private void UpdateKnockbackRotation()
    {
        Rotate(knockbackStrength);
    }

    #endregion

    #region Weapon Skills   

    #region Piercing

    private Vector2 holderOriginalPosition;

    private float currentPiercingDistance = 0;
    private float piercingCooldownTimer = 0;

    private bool CanPiercing => piercingCooldownTimer < Time.time && Mathf.Abs(CurrentSpeed) < controller.Weapon.rotationMaxSpeed * 0.1f;

    private void PiercingAttack()
    {
        if (CanPiercing)
        {
            currentPiercingDistance = Mathf.MoveTowards(currentPiercingDistance, controller.Weapon.maxPiercingDistance, controller.Weapon.piercingSpeed * Time.deltaTime);
            if (currentPiercingDistance == controller.Weapon.maxPiercingDistance) piercingCooldownTimer = controller.Weapon.piercingCooldown + Time.time;
        }
        else
            currentPiercingDistance = Mathf.MoveTowards(currentPiercingDistance, 0, controller.Weapon.piercingReturningSpeed * Time.deltaTime);

        weaponHolder.transform.localPosition = holderOriginalPosition + new Vector2(currentPiercingDistance, 0);
    }

    #endregion

    #endregion

    private void Rotate(float acceleration) 
    {
        acceleration = controller.Weapon.weaponType == WeaponType.Scimitar && !InKnockback ? Mathf.Abs(acceleration) : acceleration;
        CurrentSpeed = acceleration != 0 ? 
            Mathf.MoveTowards(CurrentSpeed, Mathf.Sign(acceleration) * controller.Weapon.rotationMaxSpeed, Mathf.Abs(acceleration) * Time.deltaTime) :
            Mathf.MoveTowards(CurrentSpeed, 0, Mathf.Abs(controller.Weapon.rotationAcc) * Time.deltaTime);
        //currentSpeed = Mathf.Clamp(currentSpeed + speed, -controller.Weapon.rotationMaxSpeed, controller.Weapon.rotationMaxSpeed);
        if (controller.Weapon.weaponType != WeaponType.Scimitar)
            controller.weaponSpriteRender.transform.localScale = 
                new Vector3(Mathf.Sign(CurrentSpeed) * controller.weaponSpriteRender.transform.localScale.x,
                                                       controller.weaponSpriteRender.transform.localScale.y, 1);
        rotationCenter.transform.Rotate(new Vector3(0, 0, CurrentSpeed * Time.deltaTime));
    }

    private void Update()
    {
        if (controller.State == PlayerState.Pop) weaponHolder.gameObject.SetActive(false);
        else weaponHolder.gameObject.SetActive(true);

        if (InKnockback) UpdateKnockbackRotation();
        else
        {
            UpdateWeaponRotation();
            if (controller.Weapon.weaponType == WeaponType.Rapier || 
                controller.Weapon.weaponType == WeaponType.Trident) 
                PiercingAttack();
        }
    }

    public void HitBubble()
    {
        if (controller.Weapon.weaponType != WeaponType.Katana || !controller.hasQuickSlash)
        {
            StartCoroutine(HitBubbleCoroutine());
        }
    }

    public IEnumerator HitBubbleCoroutine()
    {
        var weaponCol = GetComponentInChildren<BoxCollider2D>();
        weaponCol.enabled = false;
        yield return new WaitForSeconds(0.3f);
        weaponCol.enabled = true;
    }

    #region Weapon Skills

    private void LittleHammerForce()
    {
        Quaternion rotation = Quaternion.Euler(0, 0, weaponHolder.rotation.z);
        Vector3 direction = rotation * Vector3.right;

        controller.Movement.forcedMove = direction * (CurrentSpeed / controller.Weapon.rotationMaxSpeed);
    }

    #endregion
}
